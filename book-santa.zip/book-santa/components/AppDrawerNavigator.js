import React from 'react';
import { CreateDrawerNavigator } from 'react-navigation-drawer';
import { AppTabNavigator } from './AppTabNavigator';
import CustomSideBarMenu from './CustomSideBarMenu';
import SettingsScreen from '../Screens/settingsScreen';

export const AppDrawerNavigator = CreateDrawerNavigator(
  {
    Home: {
      screen: AppTabNavigator,
    },
    Setting: {
      screen: SettingsScreen,
    },
  },
  { contentComponent: CustomSideBarMenu },
  { initialRouteName: 'Home' }
);
